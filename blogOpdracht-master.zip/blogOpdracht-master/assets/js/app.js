
import 'bootstrap/dist/js/bootstrap.min';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'popper.js/dist/popper.js';

import '../scss/main.scss';
import '../css/app.css';


